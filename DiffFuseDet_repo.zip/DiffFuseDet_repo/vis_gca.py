"""
Visualize the DGA-Fusion (DGAFusion) module: two input feature maps + the fused output.

The forward pass of DGAFusion caches `_vis_x` / `_vis_y` / `_vis_out` when
`_vis_enable` is set, so no code change inside block.py is needed.
One row per DGAFusion block (P3/P4/P5); this script renders the first (highest
resolution) block as five panels: RGB, infrared, early-fusion feature,
head-aggregated feature, and fused output.

Usage:
    python vis_gca.py --weights runs/train/VEDAI/fold_9/weights/best.pt \
                      --rgb /path/to/00001090.png --ir /path/to/00001090_ir.png \
                      --save dgafusion_vis.png
"""

import argparse

import cv2
import matplotlib
import numpy as np

matplotlib.use('Agg')
import matplotlib.pyplot as plt
from ultralytics import YOLO

SCALE_NAMES = ['P3', 'P4', 'P5']


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--weights', required=True, help='trained checkpoint (.pt)')
    parser.add_argument('--rgb', required=True, help='path to the RGB image')
    parser.add_argument('--ir', required=True, help='path to the infrared image')
    parser.add_argument('--imgsz', type=int, default=1024)
    parser.add_argument('--save', default='dgafusion_vis.png', help='output figure path')
    return parser.parse_args()


def feat_to_heatmap(feat, out_size, mode='l2'):
    """Channel-reduce to a single map, then 1%-99% percentile normalisation
    so that outliers do not flatten the contrast."""
    f = feat[0]
    if mode == 'mean':
        m = f.mean(0)
    elif mode == 'abs':
        m = f.abs().mean(0)
    else:  # l2
        m = f.pow(2).mean(0).sqrt()
    m = m.cpu().numpy()
    lo, hi = np.percentile(m, 1), np.percentile(m, 99)
    m = np.clip(m, lo, hi)
    m = (m - lo) / (hi - lo + 1e-8)
    return cv2.resize(m, out_size)


def load_img(path, out_size):
    img = cv2.imread(path)
    if img is None:
        raise SystemExit(f'cannot read image: {path}')
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    return cv2.resize(img, out_size)


def main():
    args = parse_args()

    model = YOLO(args.weights)
    net = model.model

    mods = [m for m in net.modules() if type(m).__name__ == 'DGAFusion']
    print(f'found {len(mods)} DGAFusion block(s)')
    if not mods:
        raise SystemExit('no DGAFusion block found; check the weights / yaml')

    for m in mods:
        m._vis_enable = True

    # multimodal forward pass, triggers the cache
    model.predict(source=[args.rgb, args.ir], imgsz=args.imgsz, verbose=False)

    out_size = (256, 256)

    # first block = highest resolution scale
    m = mods[0]
    if not hasattr(m, '_vis_x'):
        raise SystemExit('the first DGAFusion block cached nothing; check that _vis_enable is honoured')

    fig, axes = plt.subplots(1, 5, figsize=(15, 3))
    titles = ['(a) RGB', '(b) Infrared', '(c) Early-fusion feat.', '(d) Head-agg feat.', '(e) DGA-Fusion output']

    panels = [
        load_img(args.rgb, out_size),
        load_img(args.ir, out_size),
        feat_to_heatmap(m._vis_x, out_size),
        feat_to_heatmap(m._vis_y, out_size),
        feat_to_heatmap(m._vis_out, out_size),
    ]
    for ax, img, t in zip(axes, panels, titles):
        ax.imshow(img if img.ndim == 3 else img, cmap=None if img.ndim == 3 else 'jet')
        ax.set_title(t, fontsize=10)
        ax.axis('off')

    plt.tight_layout()
    plt.savefig(args.save, dpi=150, bbox_inches='tight')
    print(f'saved: {args.save}')

    # per-scale statistics, useful to confirm that the branches carry signal
    for i, mm in enumerate(mods):
        if hasattr(mm, '_vis_x'):
            sname = SCALE_NAMES[i] if i < len(SCALE_NAMES) else f'#{i}'
            for tag, feat in [('X', mm._vis_x), ('Y', mm._vis_y), ('OUT', mm._vis_out)]:
                f = feat[0].pow(2).mean(0).sqrt().cpu().numpy()
                print(f'{sname} {tag:3s}  std={f.std():.4f}  max={f.max():.4f}  shape={tuple(feat.shape)}')


if __name__ == '__main__':
    main()
