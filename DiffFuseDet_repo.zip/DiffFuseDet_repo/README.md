# DiffFuseDet

Official implementation of the paper:

> **DiffFuseDet: Gradient-Frequency Enhanced Difference-Guided Fusion for Real-Time Multimodal Aerial Object Detection**
> Zixin Li, Ye Li
> School of Optical-Electrical and Computer Engineering, University of Shanghai for Science and Technology

DiffFuseDet is a visible--infrared (RGB--IR) object detector for aerial imagery, built on a
YOLOv11-style dual-stream backbone. Two modules are added on top of it:

| Module | Role |
| --- | --- |
| **GFEM** (Gradient--Frequency Enhancement Module) | Applied at the shallow feature-extraction stage. Combines Scharr spatial-gradient enhancement with FFT-based frequency-domain enhancement to strengthen edges and structural detail under weak-texture, low-contrast conditions. Implemented by `FreqSpatial`, wrapped by the `GFEM` / `GFEM_SpatialOnly` / `GFEM_FreqOnly` variants in `ultralytics/nn/modules/block.py`. |
| **DGA-Fusion** (Difference-Guided Adaptive Fusion) | Applied at each fusion scale (P3/P4/P5). Gates the difference between the detail-rich early-fusion feature and the semantic-rich detection-head feature, so complementary information is injected adaptively while redundant background responses are suppressed. Implemented by `DGAFusion` in `ultralytics/nn/modules/block.py`. |

Reported performance of the full model: **84.4 % mAP50** on DroneVehicle (43.7 FPS, 7.18 M parameters,
11.6 GFLOPs), **73.7 % mAP50** on VEDAI, and **88.3 % mAP50** on M3FD, with real-time inference on an
NVIDIA Jetson Orin NX 16 GB (35.6 FPS, TensorRT FP16).

## Repository layout

```
.
├── trainMM.py               # multimodal training (M3FD street scenes)
├── trainMM_kfold.py         # multimodal training with 10-fold cross-validation (VEDAI)
├── valMM.py                 # mAP@0.5 / mAP@0.5:0.95 for a trained checkpoint
├── valCOCO.py               # COCO-style evaluation against a dataset yaml
├── predictMM.py             # inference example, dual- and single-modality
├── GFEM.py                  # parameter count and FLOPs of a model configuration
├── visGFEM.py               # GFEM spatial / frequency / fused response maps
├── vis_gca.py               # DGA-Fusion input and output feature maps
├── visMM.py                 # Grad-CAM heatmaps of the fused features
├── requirements.txt         # the packages the scripts actually import
├── requirements-full.txt    # full freeze of the original environment
├── data/                    # dataset yaml templates (edit `path` before use)
├── samples/                 # put one paired RGB/IR example here
├── wiki/vis_usage.md        # argument reference for the visualization entry points
└── ultralytics/             # vendored, modified Ultralytics package
    ├── nn/modules/block.py  #   FreqSpatial, GFEM variants, CAFM, DGAFusion
    └── cfg/models/          #   model configuration files (see below)
```

### Model configurations

| File | Contents |
| --- | --- |
| `ultralytics/cfg/models/DiffFuseDet.yaml` | Full model: `GFEM` is not used here; the three `DGAFusion` blocks are enabled at P3/P4/P5 |
| `ultralytics/cfg/models/yolomm.yaml` | Dual-stream baseline, P3/P4/P5 early fusion, no GFEM, no DGA-Fusion |
| `ultralytics/cfg/models/yolomm_GFEM.yaml` | Baseline + GFEM at the frequency branch only (`GFEM_FreqOnly`, layers 2 and 13) |
| `ultralytics/cfg/models/yolomm_DGAFUSION.yaml` | Baseline + DGA-Fusion at P3/P4/P5 |
| `ultralytics/cfg/models/GFEM_FRE.yaml` | Same graph as `yolomm_GFEM.yaml`; kept for the GFEM internal ablation |
| `yolo11.yaml`, `yolo12.yaml`, `yolov10n.yaml`, `yolo26n.yaml`, `rtdetr-l.yaml` | Comparison backbones |

Config filenames are historical. Always check the layer list (and the `GFEM*` / `DGAFusion` entries
in particular) before assuming what a given file trains.

## Environment

* Ubuntu 20.04, Python 3.10, CUDA 12.1
* PyTorch 2.3.0 / torchvision 0.18.0

```bash
# install the PyTorch build matching your CUDA version first, then
pip install -r requirements.txt
```

The modified Ultralytics package is vendored in `ultralytics/` and imported directly; there is no
separate installation step and `ultralytics` should **not** be pip-installed alongside it.

## Datasets

Experiments use three public RGB--IR benchmarks. Download them from their official sources, then set
`path` in the matching yaml under `data/`. RGB and IR images must be paired by identical file stem.

| Dataset | Layout expected | Template |
| --- | --- | --- |
| DroneVehicle | `images/{train,val}` + `images_ir/{train,val}` + `labels/{train,val}` | `data/DroneVehicle.yaml` |
| VEDAI | same, split generated per fold by `trainMM_kfold.py` | `data/VEDAI.yaml` |
| M3FD | same; no official split, the paper uses a random 80 %/20 % train/test split | `data/M3FD.yaml` |

Class names in the templates are the ones used in this work and must match the integer class ids in
your `labels/*.txt` files; check them before training.

## Training

Hyperparameters used in the paper: AdamW, momentum 0.937, weight decay 0.0005, 400 epochs, batch
size 32. The scripts default to the settings that were actually used per dataset:

| Dataset | Script | imgsz | epochs | batch |
| --- | --- | --- | --- | --- |
| DroneVehicle | `trainMM.py --name DroneVehicle` | 640 | 400 | 32 |
| VEDAI (10-fold) | `trainMM_kfold.py` | 1024 | 150 | 8 |
| M3FD | `trainMM.py` | 1024 | 300 | 8 |

```bash
# M3FD
python trainMM.py --data data/M3FD.yaml --epochs 300 --batch 8 --imgsz 1024

# VEDAI, 10-fold multi-label stratified cross-validation
python trainMM_kfold.py --data data/VEDAI.yaml --epochs 150 --batch 8 --imgsz 1024

# DroneVehicle
python trainMM.py --data data/DroneVehicle.yaml --name DroneVehicle \
                  --epochs 400 --batch 32 --imgsz 640
```

`--model` selects the configuration file, so each ablation row is one run:

```bash
python trainMM.py --model ultralytics/cfg/models/yolomm.yaml            --data data/M3FD.yaml
python trainMM.py --model ultralytics/cfg/models/yolomm_GFEM.yaml       --data data/M3FD.yaml
python trainMM.py --model ultralytics/cfg/models/yolomm_DGAFUSION.yaml  --data data/M3FD.yaml
python trainMM.py --model ultralytics/cfg/models/DiffFuseDet.yaml       --data data/M3FD.yaml
```

Outputs go to `runs/train/<name>/`. `trainMM_kfold.py` writes `kfold_results.txt` with the
per-fold and per-class averages.

## Evaluation

```bash
python valMM.py   --weights runs/train/M3FD/weights/best.pt --data data/M3FD.yaml
python valCOCO.py --weights runs/train/M3FD/weights/best.pt --data data/M3FD.yaml
```

`Params` and `GFLOPs` reported in the paper come from:

```bash
python GFEM.py --model ultralytics/cfg/models/DiffFuseDet.yaml --imgsz 1024
```

## Visualization

```bash
python visGFEM.py --weights <ckpt> --rgb <rgb.png> --ir <ir.png> --out-dir gfem_vis
python vis_gca.py --weights <ckpt> --rgb <rgb.png> --ir <ir.png> --save dgafusion_vis.png
python visMM.py   --weights <ckpt> --rgb <rgb.png> --ir <ir.png>
```

`visGFEM.py` renders the spatial branch, the frequency branch and the fused GFEM response;
`vis_gca.py` renders the two DGA-Fusion inputs and its output; `visMM.py` produces Grad-CAM heatmaps.

## License

The vendored `ultralytics/` directory is distributed under **AGPL-3.0**. Because this repository
redistributes a modified copy of that package, the repository as a whole is released under
AGPL-3.0-compatible terms; see `LICENSE`. Commercial use of the vendored code requires a separate
license from Ultralytics.

## Citation

```bibtex
@article{li2026difffusedet,
  title   = {DiffFuseDet: Gradient-Frequency Enhanced Difference-Guided Fusion for Real-Time
             Multimodal Aerial Object Detection},
  author  = {Li, Zixin and Li, Ye},
  journal = {Pattern Analysis and Applications},
  year    = {2026}
}
```

## Contact

Zixin Li — first author. Corresponding author: Prof. Ye Li, liye@usst.edu.cn.
