"""
Validate a trained multimodal checkpoint (mAP@0.5 / mAP@0.5:0.95).

Usage:
    python valMM.py --weights runs/train/VEDAI_kfold_1024/fold_9/weights/best.pt \
                    --data runs/train/VEDAI_kfold_1024/fold_9/dataset/fold_9.yaml
"""

import argparse

from ultralytics import YOLOMM


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--weights', required=True, help='trained checkpoint (.pt)')
    parser.add_argument('--data', required=True, help='dataset yaml used for validation')
    parser.add_argument('--split', default='val')
    parser.add_argument('--device', default='0', help="'0' for the first GPU, 'cpu' for CPU")
    parser.add_argument('--imgsz', type=int, default=1024)
    parser.add_argument('--project', default='runs/val')
    parser.add_argument('--name', default='val')
    return parser.parse_args()


if __name__ == '__main__':
    args = parse_args()

    model = YOLOMM(args.weights)
    model.val(data=args.data,
              split=args.split,
              device=args.device,
              imgsz=args.imgsz,
              project=args.project,
              name=args.name)
