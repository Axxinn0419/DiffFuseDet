"""
Grad-CAM / heatmap visualization of the fused features (Fig. 7).

Usage:
    python visMM.py --weights runs/train/VEDAI/weights/best.pt \
                    --rgb /path/to/00000930.png --ir /path/to/00000930_ir.png
"""

import argparse

import cv2
from ultralytics import YOLOMM


def ensure_3channel(img_path):
    """确保图像为3通道RGB"""
    img = cv2.imread(img_path, cv2.IMREAD_UNCHANGED)

    if img is None:
        raise ValueError(f"无法读取图像: {img_path}")

    # 检查通道数
    if len(img.shape) == 2:  # 灰度图
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
    elif img.shape[2] == 4:  # RGBA
        img = cv2.cvtColor(img, cv2.COLOR_BGRA2RGB)
    elif img.shape[2] == 3:  # BGR
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    return img


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--weights', required=True, help='trained checkpoint (.pt)')
    parser.add_argument('--rgb', required=True, help='path to the RGB image')
    parser.add_argument('--ir', required=True, help='path to the infrared image')
    parser.add_argument('--layer', type=int, default=41, help='index of the layer to visualize')
    parser.add_argument('--project', default='runs/vis')
    parser.add_argument('--name', default='YOLOMM_ALL')
    args = parser.parse_args()

    model = YOLOMM(args.weights)

    rgb_img = ensure_3channel(args.rgb)
    x_img = ensure_3channel(args.ir)

    model.vis(
        rgb_source=rgb_img,  # pass the already preprocessed array
        x_source=x_img,
        method='heatmap',
        layers=[args.layer],
        overlay='rgb',
        alg='gradcam',
        save=True,
        project=args.project,
        name=args.name
    )


if __name__ == '__main__':
    main()