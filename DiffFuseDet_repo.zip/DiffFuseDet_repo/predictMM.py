"""
Reference inference example for the multimodal (RGB + infrared) detector.

The two modalities are passed as a list [rgb, ir]; pass a single path with
`--modality rgb` or `--modality X` to run the single-modality variants.

Usage:
    python predictMM.py --weights runs/train/VEDAI/weights/best.pt \
                        --rgb samples/00002_rgb.png --ir samples/00002_ir.png
"""

import argparse

from ultralytics import YOLOMM


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--weights', required=True, help='trained checkpoint (.pt)')
    parser.add_argument('--rgb', required=True, help='path to the RGB image')
    parser.add_argument('--ir', help='path to the infrared image; omit for a single-modality run')
    parser.add_argument('--modality', default='rgb', choices=['rgb', 'X'],
                        help='modality used when --ir is not given')
    parser.add_argument('--project', default='runs/predict')
    parser.add_argument('--name', default='predict')
    return parser.parse_args()


if __name__ == '__main__':
    args = parse_args()
    model = YOLOMM(args.weights)

    if args.ir:
        print('=== dual modality ===')
        model.predict([args.rgb, args.ir],
                      project=args.project,
                      name=f'{args.name}_dual',
                      save=True,
                      exist_ok=True)
    else:
        print(f'=== single modality ({args.modality}) ===')
        source = args.rgb if args.modality == 'rgb' else (args.ir or args.rgb)
        model.predict(source,
                      project=args.project,
                      name=f'{args.name}_single_{args.modality}',
                      save=True,
                      modality=args.modality,
                      exist_ok=True)
