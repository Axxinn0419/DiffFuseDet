place one paired RGB/IR example here (e.g. samples/00002_rgb.png, samples/00002_ir.png)
