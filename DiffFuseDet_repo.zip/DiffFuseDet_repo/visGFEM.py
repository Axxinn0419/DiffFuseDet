"""
Visualize the two branches of GFEM (spatial / frequency) and the fused response.

Usage:
    python visGFEM.py --weights runs/train/VEDAI_GFEM/fold_1/weights/best.pt \
                      --rgb /path/to/00000025.png --ir /path/to/00000025_ir.png \
                      --out-dir gfem_vis
"""

import argparse
import os

import cv2
import matplotlib
import numpy as np

matplotlib.use('Agg')
import matplotlib.pyplot as plt
from ultralytics import YOLOMM


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--weights', required=True, help='trained checkpoint (.pt)')
    parser.add_argument('--rgb', required=True, help='path to the RGB image')
    parser.add_argument('--ir', required=True, help='path to the infrared image')
    parser.add_argument('--out-dir', default='gfem_vis', help='directory for the output figures')
    parser.add_argument('--imgsz', type=int, default=1024)
    parser.add_argument('--mode', default='abs', choices=['mean', 'abs', 'l2', 'std'],
                        help='channel reduction used for the response maps')
    return parser.parse_args()


def feat_to_heatmap(feat, out_size, mode='abs'):
    f = feat[0]
    if mode == 'mean':
        m = f.mean(0)
    elif mode == 'abs':
        m = f.abs().mean(0)
    elif mode == 'l2':
        m = f.pow(2).mean(0).sqrt()
    elif mode == 'std':
        m = f.std(0)
    m = m.cpu().numpy()
    lo, hi = np.percentile(m, 1), np.percentile(m, 99)
    m = np.clip(m, lo, hi)
    m = (m - lo) / (hi - lo + 1e-8)
    return cv2.resize(m, out_size)


def overlay(img_bgr, hm):
    cm = cv2.applyColorMap(np.uint8(255 * hm), cv2.COLORMAP_JET)
    return cv2.addWeighted(img_bgr, 0.5, cm, 0.5, 0)


def main():
    args = parse_args()
    os.makedirs(args.out_dir, exist_ok=True)

    print('loading model...')
    model = YOLOMM(args.weights)
    net = model.model
    net.eval()

    from ultralytics.nn.modules.block import FreqSpatial
    fs_list = [m for m in net.modules() if isinstance(m, FreqSpatial)]
    print(f'found {len(fs_list)} FreqSpatial block(s)')
    if not fs_list:
        raise SystemExit('no FreqSpatial block found; check the weights / yaml')
    for m in fs_list:
        m._vis_enable = True

    print(f'processing: {os.path.basename(args.rgb)}')
    model.predict(source=[args.rgb, args.ir], imgsz=args.imgsz, save=False)

    original = cv2.imread(args.rgb)
    if original is None:
        raise SystemExit(f'cannot read image: {args.rgb}')
    H, W = original.shape[:2]

    fs = fs_list[0]
    spatial_hm = feat_to_heatmap(fs._vis_spatial, (W, H), args.mode)
    freq_hm = feat_to_heatmap(fs._vis_freq, (W, H), args.mode)
    final_hm = feat_to_heatmap(fs._vis_final, (W, H), args.mode)

    ov_spatial = overlay(original, spatial_hm)
    ov_freq = overlay(original, freq_hm)
    ov_final = overlay(original, final_hm)

    # single row: input | spatial branch | frequency branch | GFEM output
    fig, axes = plt.subplots(1, 4, figsize=(20, 5))
    titles = ['Input (RGB)', 'Spatial Branch', 'Frequency Branch', 'GFEM']
    imgs = [original, ov_spatial, ov_freq, ov_final]

    for ax, t, im in zip(axes, titles, imgs):
        ax.imshow(im[..., ::-1])
        ax.set_title(t, fontsize=14)
        ax.axis('off')

    plt.tight_layout()
    out_path = os.path.join(args.out_dir, 'gfem_comparison.png')
    plt.savefig(out_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f'saved comparison figure: {out_path}')

    cv2.imwrite(os.path.join(args.out_dir, 'spatial.png'), ov_spatial)
    cv2.imwrite(os.path.join(args.out_dir, 'frequency.png'), ov_freq)
    cv2.imwrite(os.path.join(args.out_dir, 'gfem_output.png'), ov_final)
    print(f'individual maps saved to: {args.out_dir}')


if __name__ == '__main__':
    main()
