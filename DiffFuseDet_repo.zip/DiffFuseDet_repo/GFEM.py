"""
Report parameter count and FLOPs of a model configuration (no training).

FLOPs are counted on a single-modality input tensor, which is how the numbers
in the paper's complexity table are obtained.

Usage:
    python GFEM.py --model ultralytics/cfg/models/DiffFuseDet.yaml --imgsz 1024
"""

import argparse

import torch
from ultralytics import YOLOMM


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--model', default='ultralytics/cfg/models/DiffFuseDet.yaml',
                        help='model configuration file (not a checkpoint)')
    parser.add_argument('--imgsz', type=int, nargs='+', default=[1024],
                        help='one or more input sizes to profile')
    return parser.parse_args()


if __name__ == '__main__':
    args = parse_args()

    model = YOLOMM(args.model)
    model.model.eval()

    for mod in model.model.modules():
        if type(mod).__name__ == 'GFEM':
            print(f'GFEM block with n={len(mod.m)} FreqSpatial sub-modules')

    n_params = sum(p.numel() for p in model.model.parameters())
    print(f'\nParameters: {n_params / 1e6:.3f} M')

    try:
        from thop import clever_format, profile
    except ImportError:
        print('\nthop is not installed, skipping FLOPs (pip install thop)')
        raise SystemExit(0)

    for size in args.imgsz:
        try:
            flops, _ = profile(model.model, inputs=(torch.randn(1, 3, size, size),), verbose=False)
            print(f'GFLOPs ({size}x{size}): {clever_format([flops], "%.3f")[0]}')
        except Exception as exc:  # noqa: BLE001 - profiling can fail on custom ops
            print(f'FLOPs profiling failed at {size}x{size}: {exc}')
            print('The model contains custom operations that thop may not trace.')
