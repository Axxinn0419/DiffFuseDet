"""
COCO-style evaluation (AP50:95 with COCO metrics) on a dataset yaml.

Usage:
    python valCOCO.py --weights runs/train/VEDAI/weights/best.pt --data data/VEDAI.yaml
"""

import argparse

from ultralytics import YOLOMM


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--weights', required=True, help='trained checkpoint (.pt)')
    parser.add_argument('--data', required=True, help='dataset yaml')
    parser.add_argument('--split', default='val')
    parser.add_argument('--device', default='0', help="'0' for the first GPU, 'cpu' for CPU")
    parser.add_argument('--imgsz', type=int, default=1024)
    parser.add_argument('--batch', type=int, default=1)
    parser.add_argument('--project', default='runs/val')
    parser.add_argument('--name', default='coco')
    return parser.parse_args()


if __name__ == '__main__':
    args = parse_args()

    model = YOLOMM(args.weights)
    model.cocoval(data=args.data,
                  split=args.split,
                  device=args.device,
                  half=False,
                  imgsz=args.imgsz,
                  batch=args.batch,
                  project=args.project,
                  name=args.name)
