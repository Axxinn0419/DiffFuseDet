"""
YOLOMM 十折多标签分层交叉验证训练脚本
适用于 VEDAI 多模态(RGB + IR)数据集

运行方式: python trainMM_kfold.py --data /path/to/vedai.yaml --project runs/train
"""

import argparse
import os
import yaml
import shutil
import numpy as np
from pathlib import Path
from iterstrat.ml_stratifiers import MultilabelStratifiedKFold
from ultralytics import YOLOMM
import torch

# ============ 系统设置（必须在所有代码之前） ============
# 强制使用 float32
torch.set_default_dtype(torch.float32)
torch.backends.cudnn.deterministic = False
torch.backends.cudnn.benchmark = True
torch.backends.cudnn.enabled = True

# 环境变量
os.environ['CUBLAS_WORKSPACE_CONFIG'] = ':4096:8'
os.environ['PYTORCH_CUDA_ALLOC_CONF'] = 'max_split_size_mb:512'
os.environ['OMP_NUM_THREADS'] = '4'
os.environ['MKL_NUM_THREADS'] = '4'

# ================= 配置区域 ========================
# 默认值可用命令行覆盖，见文件末尾的 parse_args()

MODEL_CFG = 'ultralytics/cfg/models/yolomm.yaml'
DATA_YAML = 'data/VEDAI.yaml'
PROJECT_DIR = 'runs/train'
EXPERIMENT_NAME = 'VEDAI_kfold_1024'

EPOCHS = 150
BATCH_SIZE = 8
IMG_SIZE = 1024
WORKERS = 8
N_FOLDS = 10
RANDOM_SEED = 42
USE_AMP = False
CACHE_DATA = False

# 配置：从第5折开始训练（包含第5折）
FORCE_RETRAIN = []  # 清空，不强制重新训练
START_FOLD = 1  # 从第几折开始训练


# =================================================


def get_image_files(images_dir):
    img_formats = ('.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff', '.webp')
    files = []
    img_path = Path(images_dir)
    for fmt in img_formats:
        files.extend(img_path.rglob(f'*{fmt}'))
    return sorted(files)


def collect_all_samples(data_yaml_path):
    with open(data_yaml_path, 'r', encoding='utf-8') as f:
        data_cfg = yaml.safe_load(f)

    dataset_root = Path(data_cfg.get('path', '')).resolve()
    all_stems = set()

    for split_rel in [data_cfg.get('train', ''), data_cfg.get('val', ''), data_cfg.get('test', '')]:
        if not split_rel:
            continue

        split_path = dataset_root / split_rel
        if split_path.exists():
            for img in get_image_files(split_path):
                all_stems.add(img.stem)

    if not all_stems:
        images_dir = dataset_root / 'images'
        if images_dir.exists():
            for img in get_image_files(images_dir):
                all_stems.add(img.stem)

    return sorted(list(all_stems)), data_cfg


def find_file_by_stem(search_dir, stem, ext=None):
    search_dir = Path(search_dir)
    if not search_dir.exists():
        return None

    if ext:
        candidates = list(search_dir.rglob(f'{stem}{ext}'))
    else:
        candidates = list(search_dir.rglob(f'{stem}.*'))

    return candidates[0] if candidates else None


def get_class_names(data_yaml_path):
    with open(data_yaml_path, 'r', encoding='utf-8') as f:
        data_cfg = yaml.safe_load(f)

    names = data_cfg.get('names', {})
    if isinstance(names, list):
        return {i: n for i, n in enumerate(names)}

    return {int(k): v for k, v in names.items()}


def get_label_dir_name(data_cfg):
    return data_cfg.get('labels', 'labels')


def read_classes_from_label(label_path):
    classes = set()

    if label_path is None or not Path(label_path).exists():
        return classes

    with open(label_path, 'r', encoding='utf-8') as f:
        for line in f:
            parts = line.strip().split()
            if parts:
                classes.add(int(float(parts[0])))

    return classes


def build_multilabel_targets(all_stems, dataset_root, data_cfg, nc):
    label_dir_name = get_label_dir_name(data_cfg)
    y = np.zeros((len(all_stems), nc), dtype=int)

    for i, stem in enumerate(all_stems):
        label_path = find_file_by_stem(Path(dataset_root) / label_dir_name, stem, ext='.txt')
        classes = read_classes_from_label(label_path)

        for c in classes:
            if 0 <= c < nc:
                y[i, c] = 1

    return y


def check_class_coverage(y, class_names, n_folds):
    class_counts = y.sum(axis=0)

    print('\n--- 数据集中各类别图像数量统计 ---')
    for c, count in enumerate(class_counts):
        name = class_names.get(c, f'class_{c}')
        print(f'{name:<20}: {int(count)}')

    missing_classes = [c for c, count in enumerate(class_counts) if count == 0]
    if missing_classes:
        names = [class_names.get(c, f'class_{c}') for c in missing_classes]
        raise ValueError(f'数据集中以下类别没有样本，无法训练: {names}')

    rare_classes = [c for c, count in enumerate(class_counts) if count < n_folds]
    if rare_classes:
        names = [class_names.get(c, f'class_{c}') for c in rare_classes]
        raise ValueError(
            f'以下类别的样本图像数少于 {n_folds}，无法保证每一折验证集都有该类别: {names}'
        )


def validate_fold_coverage(y, train_indices, val_indices, class_names, fold_idx):
    train_counts = y[train_indices].sum(axis=0)
    val_counts = y[val_indices].sum(axis=0)

    train_missing = np.where(train_counts == 0)[0]
    val_missing = np.where(val_counts == 0)[0]

    if len(train_missing) > 0 or len(val_missing) > 0:
        msg = [f'Fold {fold_idx} 类别覆盖检查失败:']

        if len(train_missing) > 0:
            names = [class_names.get(int(c), f'class_{int(c)}') for c in train_missing]
            msg.append(f'训练集缺少类别: {names}')

        if len(val_missing) > 0:
            names = [class_names.get(int(c), f'class_{int(c)}') for c in val_missing]
            msg.append(f'验证集缺少类别: {names}')

        raise ValueError('\n'.join(msg))

    print(f'\nFold {fold_idx} 类别覆盖检查通过')


def create_fold_symlinks(dataset_root, train_stems, val_stems, fold_dir, data_cfg):
    fold_dir = Path(fold_dir)
    dataset_root = Path(dataset_root)

    rgb_dir_name = 'images'
    ir_dir_name = 'images_ir'
    label_dir_name = 'labels'

    modality_cfg = data_cfg.get('modality', data_cfg.get('modalities', {}))
    if modality_cfg:
        rgb_dir_name = modality_cfg.get('rgb', 'images')
        ir_dir_name = modality_cfg.get('ir', 'images_ir')

    for split_name, stems in [('train', train_stems), ('val', val_stems)]:
        rgb_split_dir = fold_dir / rgb_dir_name / split_name
        ir_split_dir = fold_dir / ir_dir_name / split_name
        label_split_dir = fold_dir / label_dir_name / split_name

        rgb_split_dir.mkdir(parents=True, exist_ok=True)
        ir_split_dir.mkdir(parents=True, exist_ok=True)
        label_split_dir.mkdir(parents=True, exist_ok=True)

        for stem in stems:
            src_rgb = find_file_by_stem(dataset_root / rgb_dir_name, stem)
            src_ir = find_file_by_stem(dataset_root / ir_dir_name, stem)
            src_label = find_file_by_stem(dataset_root / label_dir_name, stem, ext='.txt')

            if src_rgb:
                dst = rgb_split_dir / src_rgb.name
                if not dst.exists():
                    os.symlink(src_rgb, dst)

            if src_ir:
                dst = ir_split_dir / src_ir.name
                if not dst.exists():
                    os.symlink(src_ir, dst)

            if src_label:
                dst = label_split_dir / src_label.name
                if not dst.exists():
                    os.symlink(src_label, dst)


def create_fold_yaml(fold_dir, data_cfg, fold_idx):
    fold_yaml = dict(data_cfg)
    fold_yaml['path'] = str(fold_dir)
    fold_yaml['train'] = 'images/train'
    fold_yaml['val'] = 'images/val'
    fold_yaml.pop('test', None)

    yaml_path = fold_dir / f'fold_{fold_idx}.yaml'
    with open(yaml_path, 'w', encoding='utf-8') as f:
        yaml.dump(fold_yaml, f, default_flow_style=False, allow_unicode=True)

    return str(yaml_path)


def extract_per_class_metrics(metrics, nc):
    per_class_ap50 = np.full(nc, np.nan)
    per_class_map = np.full(nc, np.nan)

    if metrics is None:
        return per_class_ap50, per_class_map

    try:
        box = metrics.box
        for i, c in enumerate(box.ap_class_index):
            per_class_ap50[int(c)] = box.ap50[i]
            per_class_map[int(c)] = box.ap[i]
    except Exception:
        pass

    return per_class_ap50, per_class_map


def clean_fold_for_retrain(fold_num):
    """清理指定折的目录，准备重新训练（不备份）"""
    fold_dir = Path(PROJECT_DIR) / EXPERIMENT_NAME / f'fold_{fold_num}'

    if fold_dir.exists():
        print(f'清理折 {fold_num} 的原有结果（不备份）...')
        shutil.rmtree(fold_dir)

    fold_dir.mkdir(parents=True, exist_ok=True)
    print(f'已为折 {fold_num} 创建新目录')


def prepare_model_for_training(model):
    """准备模型：强制所有参数为 float32"""
    print("\n=== 准备模型（强制 float32）===")

    if not hasattr(model, 'model'):
        print("警告: 模型没有 'model' 属性")
        return model

    # 1. 转换整个模型为 float32
    model.model = model.model.float()

    # 2. 转换所有参数
    param_count = 0
    for name, param in model.model.named_parameters():
        if param.dtype != torch.float32:
            param.data = param.data.float()
            param_count += 1
            if param_count <= 5:  # 只打印前5个
                print(f"  转换参数: {name}")

    # 3. 转换所有 buffer
    buffer_count = 0
    for name, buffer in model.model.named_buffers():
        if buffer.dtype != torch.float32:
            buffer.data = buffer.data.float()
            buffer_count += 1
            if buffer_count <= 5:
                print(f"  转换 buffer: {name}")

    # 4. 验证
    print("\n验证模型参数类型:")
    all_float32 = True
    for name, param in model.named_parameters():
        if param.dtype != torch.float32:
            print(f"  ❌ {name}: {param.dtype}")
            all_float32 = False
            break
    if all_float32:
        print("  ✅ 所有参数都是 float32")

    print("=== 模型准备完成 ===\n")
    return model


def get_training_status(fold_dir):
    """获取训练进度信息"""
    results_file = Path(fold_dir) / 'results.csv'
    if results_file.exists():
        try:
            import pandas as pd
            df = pd.read_csv(results_file)
            return len(df) - 1  # 已完成轮数
        except:
            return None
    return None


def main():
    # 确定起始折
    if FORCE_RETRAIN:
        start_fold = min(FORCE_RETRAIN)
        print(f'强制重新训练折: {FORCE_RETRAIN}')
    else:
        start_fold = START_FOLD

    print(f'{"=" * 60}')
    print(f'  YOLOMM {N_FOLDS}折多标签分层交叉验证')
    print(f'  模型: {Path(MODEL_CFG).stem}')
    print(f'  数据集: {Path(DATA_YAML).stem}')
    print(f'  Epochs: {EPOCHS} | Batch: {BATCH_SIZE} | ImgSize: {IMG_SIZE}')
    print(f'  将从第 {start_fold} 折开始训练（包括该折及之后的所有折）')
    if FORCE_RETRAIN:
        print(f'  强制重新训练: 第 {FORCE_RETRAIN} 折')
    print(f'  AMP: {USE_AMP} (混合精度训练)')
    print(f'{"=" * 60}\n')

    all_stems, data_cfg = collect_all_samples(DATA_YAML)
    class_names = get_class_names(DATA_YAML)
    nc = len(class_names)

    print(f'样本总数: {len(all_stems)}')
    print(f'类别数: {nc} -> {list(class_names.values())}\n')

    dataset_root = Path(data_cfg.get('path', '')).resolve()

    y_multilabel = build_multilabel_targets(all_stems, dataset_root, data_cfg, nc)
    check_class_coverage(y_multilabel, class_names, N_FOLDS)

    kf = MultilabelStratifiedKFold(
        n_splits=N_FOLDS,
        shuffle=True,
        random_state=RANDOM_SEED
    )

    # 清理需要强制重新训练的折
    for fold_num in FORCE_RETRAIN:
        if 1 <= fold_num <= N_FOLDS:
            clean_fold_for_retrain(fold_num)
        else:
            print(f'警告: 折 {fold_num} 超出范围 (1-{N_FOLDS})，跳过')

    all_ap50 = np.full((N_FOLDS, nc), np.nan)
    all_map = np.full((N_FOLDS, nc), np.nan)
    fold_overall = []

    # 处理所有折
    for fold_idx, (train_indices, val_indices) in enumerate(kf.split(np.zeros(len(all_stems)), y_multilabel)):
        fold_num = fold_idx + 1

        # 如果当前折小于起始折，只加载结果，不训练
        if fold_num < start_fold:
            print(f'\n折 {fold_num} < 起始折 {start_fold}，加载已有结果...')
            fold_train_dir = Path(PROJECT_DIR) / EXPERIMENT_NAME / f'fold_{fold_num}'
            best_pt = fold_train_dir / 'weights' / 'best.pt'

            if best_pt.exists():
                model = YOLOMM(str(best_pt))
                fold_dir = Path(PROJECT_DIR) / EXPERIMENT_NAME / f'fold_{fold_num}' / 'dataset'
                fold_yaml_path = str(fold_dir / f'fold_{fold_num}.yaml')

                metrics = model.val(data=fold_yaml_path, imgsz=IMG_SIZE)
                per_class_ap50, per_class_map = extract_per_class_metrics(metrics, nc)
                all_ap50[fold_idx] = per_class_ap50
                all_map[fold_idx] = per_class_map

                try:
                    fold_overall.append((metrics.box.map50, metrics.box.map))
                    print(f'折 {fold_num} 结果: mAP@0.5={metrics.box.map50:.4f}, mAP@0.5:0.95={metrics.box.map:.4f}')
                except Exception:
                    fold_overall.append((np.nan, np.nan))
            else:
                print(f'错误: 折 {fold_num} 没有训练结果！')
                fold_overall.append((np.nan, np.nan))
            continue

        # 训练当前折
        validate_fold_coverage(
            y_multilabel,
            train_indices,
            val_indices,
            class_names,
            fold_num
        )

        print(f'\n{"=" * 60}')
        print(f'  Fold {fold_num}/{N_FOLDS}  '
              f'(Train: {len(train_indices)}, Val: {len(val_indices)})')
        if fold_num in FORCE_RETRAIN:
            print(f'  *** 强制重新训练模式 ***')
        print(f'{"=" * 60}\n')

        train_stems = [all_stems[i] for i in train_indices]
        val_stems = [all_stems[i] for i in val_indices]

        fold_dir = Path(PROJECT_DIR) / EXPERIMENT_NAME / f'fold_{fold_num}' / 'dataset'
        fold_dir.mkdir(parents=True, exist_ok=True)

        create_fold_symlinks(dataset_root, train_stems, val_stems, fold_dir, data_cfg)
        fold_yaml_path = create_fold_yaml(fold_dir, data_cfg, fold_num)

        # ============ 检查是否有checkpoint可以恢复 ============
        fold_train_dir = Path(PROJECT_DIR) / EXPERIMENT_NAME / f'fold_{fold_num}'
        last_pt_path = fold_train_dir / 'weights' / 'last.pt'

        # ============ 开始训练 ============
        print("\n加载模型...")

        # 判断是否从checkpoint恢复
        if last_pt_path.exists() and fold_num not in FORCE_RETRAIN:
            print(f"发现已保存的checkpoint: {last_pt_path}")

            # 获取训练进度
            current_epoch = get_training_status(fold_train_dir)
            if current_epoch is not None:
                print(f"当前已完成 {current_epoch} 轮，将继续训练至 {EPOCHS} 轮")
            else:
                print("将从断点处恢复训练（无法读取具体轮数）")

            # 加载模型（从checkpoint恢复）
            model = YOLOMM(str(last_pt_path))

            print(f"开始恢复训练 Fold {fold_num}...")
            print(f"  数据: {fold_yaml_path}")
            print(f"  Batch: {BATCH_SIZE}, Workers: {WORKERS}, AMP: {USE_AMP}")
            print(f"  恢复模式: resume=True")
            print()

            # 恢复训练
            metrics = model.train(
                data=fold_yaml_path,
                epochs=EPOCHS,
                batch=BATCH_SIZE,
                imgsz=IMG_SIZE,
                exist_ok=True,
                workers=WORKERS,
                project=str(Path(PROJECT_DIR) / EXPERIMENT_NAME),
                name=f'fold_{fold_num}',
                amp=USE_AMP,
                cache=CACHE_DATA,
                resume=True,  # 关键：从last.pt恢复训练
                # 优化器
                optimizer='AdamW',
                lr0=0.001,
                lrf=0.01,
                momentum=0.937,
                weight_decay=0.0005,
                warmup_epochs=3,
                warmup_momentum=0.8,
                warmup_bias_lr=0.1,
                # 损失权重
                box=7.5,
                cls=0.5,
                dfl=1.5,
                # 数据增强
                mosaic=0.5,
                mixup=0.0,
                copy_paste=0.0,
                seed=RANDOM_SEED,
                verbose=True,
            )
        else:
            # 全新训练
            if not last_pt_path.exists():
                print("未发现已有checkpoint，开始全新训练...")
            else:
                print(f"折 {fold_num} 在强制重新训练列表中，开始全新训练...")

            model = YOLOMM(MODEL_CFG)
            model = prepare_model_for_training(model)

            print(f"开始训练 Fold {fold_num}...")
            print(f"  数据: {fold_yaml_path}")
            print(f"  Batch: {BATCH_SIZE}, Workers: {WORKERS}, AMP: {USE_AMP}")
            print()

            metrics = model.train(
                data=fold_yaml_path,
                epochs=EPOCHS,
                batch=BATCH_SIZE,
                imgsz=IMG_SIZE,
                exist_ok=True,
                workers=WORKERS,
                project=str(Path(PROJECT_DIR) / EXPERIMENT_NAME),
                name=f'fold_{fold_num}',
                amp=USE_AMP,
                cache=CACHE_DATA,
                resume=False,
                # 优化器
                optimizer='AdamW',
                lr0=0.001,
                lrf=0.01,
                momentum=0.937,
                weight_decay=0.0005,
                warmup_epochs=3,
                warmup_momentum=0.8,
                warmup_bias_lr=0.1,
                # 损失权重
                box=7.5,
                cls=0.5,
                dfl=1.5,
                # 数据增强
                mosaic=0.5,
                mixup=0.0,
                copy_paste=0.0,
                seed=RANDOM_SEED,
                verbose=True,
            )
        # ============ 训练结束 ============

        per_class_ap50, per_class_map = extract_per_class_metrics(metrics, nc)
        all_ap50[fold_idx] = per_class_ap50
        all_map[fold_idx] = per_class_map

        if metrics is not None:
            try:
                overall_map50 = metrics.box.map50
                overall_map = metrics.box.map
                fold_overall.append((overall_map50, overall_map))
                print(f'\nFold {fold_num} 完成: mAP@0.5={overall_map50:.4f}, mAP@0.5:0.95={overall_map:.4f}')
            except Exception:
                fold_overall.append((np.nan, np.nan))
        else:
            fold_overall.append((np.nan, np.nan))

    print_summary(all_ap50, all_map, fold_overall, class_names, nc)


def print_summary(all_ap50, all_map, fold_overall, class_names, nc):
    print(f'\n{"=" * 60}')
    print(f'  {N_FOLDS}折多标签分层交叉验证 最终结果汇总')
    print(f'{"=" * 60}\n')

    fold_overall = np.array(fold_overall, dtype=float)

    print(f'{"Fold":<8} {"mAP@0.5":<14} {"mAP@0.5:0.95":<16}')
    print('-' * 42)

    for i, (m50, m) in enumerate(fold_overall):
        print(f'{i + 1:<8} {m50:<14.4f} {m:<16.4f}')

    print('-' * 42)

    mean_m50 = np.nanmean(fold_overall[:, 0])
    mean_m = np.nanmean(fold_overall[:, 1])
    std_m50 = np.nanstd(fold_overall[:, 0])
    std_m = np.nanstd(fold_overall[:, 1])

    print(f'{"Mean":<8} {mean_m50:<14.4f} {mean_m:<16.4f}')
    print(f'{"Std":<8} {std_m50:<14.4f} {std_m:<16.4f}')

    print(f'\n最终结果:')
    print(f'mAP@0.5      = {mean_m50:.4f} ± {std_m50:.4f}')
    print(f'mAP@0.5:0.95 = {mean_m:.4f} ± {std_m:.4f}')

    print(f'\n--- 各类别 AP@0.5 统计 ---\n')
    print(f'{"类别":<20} {"AP@0.5":<12} {"Std":<12}')
    print('-' * 44)

    for c in range(nc):
        name = class_names.get(c, f'class_{c}')
        mean_ap50 = np.nanmean(all_ap50[:, c])
        std_ap50 = np.nanstd(all_ap50[:, c])
        print(f'{name:<20} {mean_ap50:<12.4f} {std_ap50:<12.4f}')

    print(f'\n--- 各类别 AP@0.5:0.95 统计 ---\n')
    print(f'{"类别":<20} {"AP@0.5:0.95":<14} {"Std":<12}')
    print('-' * 48)

    for c in range(nc):
        name = class_names.get(c, f'class_{c}')
        mean_map = np.nanmean(all_map[:, c])
        std_map = np.nanstd(all_map[:, c])
        print(f'{name:<20} {mean_map:<14.4f} {std_map:<12.4f}')

    save_path = Path(PROJECT_DIR) / EXPERIMENT_NAME / 'kfold_results.txt'

    with open(save_path, 'w', encoding='utf-8') as f:
        f.write(f'{N_FOLDS}-Fold Multilabel Stratified Cross Validation Results\n')
        f.write(f'Model: {MODEL_CFG}\n')
        f.write(f'Dataset: {DATA_YAML}\n')
        f.write(f'Epochs: {EPOCHS}, Batch: {BATCH_SIZE}, ImgSize: {IMG_SIZE}, Seed: {RANDOM_SEED}\n')

        if FORCE_RETRAIN:
            f.write(f'Force retrained folds: {FORCE_RETRAIN}\n')

        f.write('Overall fold results:\n')
        for i, (m50, m) in enumerate(fold_overall):
            f.write(f'Fold {i + 1}: mAP@0.5={m50:.4f}, mAP@0.5:0.95={m:.4f}\n')

        f.write('\nFinal Results:\n')
        f.write(f'mAP@0.5={mean_m50:.4f}±{std_m50:.4f}\n')
        f.write(f'mAP@0.5:0.95={mean_m:.4f}±{std_m:.4f}\n')

        f.write('Per-class AP@0.5:\n')
        for c in range(nc):
            name = class_names.get(c, f'class_{c}')
            f.write(f'  {name}: {np.nanmean(all_ap50[:, c]):.4f}±{np.nanstd(all_ap50[:, c]):.4f}\n')

        f.write('\nPer-class AP@0.5:0.95:\n')
        for c in range(nc):
            name = class_names.get(c, f'class_{c}')
            f.write(f'  {name}: {np.nanmean(all_map[:, c]):.4f}±{np.nanstd(all_map[:, c]):.4f}\n')

    print(f'\n结果已保存至: {save_path}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='10-fold multilabel stratified CV on VEDAI')
    parser.add_argument('--model', default=MODEL_CFG, help='model configuration file')
    parser.add_argument('--data', default=DATA_YAML, help='dataset yaml (path/train/val/names)')
    parser.add_argument('--project', default=PROJECT_DIR, help='output root directory')
    parser.add_argument('--name', default=EXPERIMENT_NAME, help='experiment name')
    parser.add_argument('--epochs', type=int, default=EPOCHS)
    parser.add_argument('--batch', type=int, default=BATCH_SIZE)
    parser.add_argument('--imgsz', type=int, default=IMG_SIZE)
    parser.add_argument('--workers', type=int, default=WORKERS)
    parser.add_argument('--folds', type=int, default=N_FOLDS)
    parser.add_argument('--start-fold', type=int, default=START_FOLD,
                        help='first fold to train; earlier folds are only evaluated if checkpoints exist')
    parser.add_argument('--seed', type=int, default=RANDOM_SEED)
    args = parser.parse_args()

    MODEL_CFG = args.model
    DATA_YAML = args.data
    PROJECT_DIR = args.project
    EXPERIMENT_NAME = args.name
    EPOCHS = args.epochs
    BATCH_SIZE = args.batch
    IMG_SIZE = args.imgsz
    WORKERS = args.workers
    N_FOLDS = args.folds
    START_FOLD = args.start_fold
    RANDOM_SEED = args.seed

    main()