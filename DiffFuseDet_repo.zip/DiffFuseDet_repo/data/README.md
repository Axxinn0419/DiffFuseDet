# Dataset descriptions

Each `*.yaml` here is a template. Point `path` at the root of your local copy of
the dataset and keep the layout below; the RGB and infrared images must be paired
by identical file stem (`00002.png` in both `images/` and `images_ir/`).

```
<dataset root>
├── images/{train,val}/     # RGB frames
├── images_ir/{train,val}/  # infrared frames
└── labels/{train,val}/     # YOLO-format annotations
```

`trainMM_kfold.py` reads `path`, `train`, `val`, `names`, and the optional
`modality: {rgb: ..., ir: ...}` mapping from the yaml, and builds the per-fold
directories itself.
