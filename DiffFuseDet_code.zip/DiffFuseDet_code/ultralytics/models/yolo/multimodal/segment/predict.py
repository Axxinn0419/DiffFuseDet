from ultralytics.models.yolo.segment.predict import SegmentationPredictor
from ultralytics.models.yolo.multimodal.predict import MultiModalDetectionPredictor


class MultiModalSegmentationPredictor(MultiModalDetectionPredictor, SegmentationPredictor):
    """
    Multimodal segmentation predictor.

    Inherits multimodal input handling, preprocessing and visualization layout
    from the detection-side predictor, while leveraging segmentation plotting
    from the segmentation base where applicable.

    Further mask-specific visual overlays can be extended later while keeping
    the multimodal input semantics unchanged.
    """

    def write_results(self, i, p, im, s) -> str:
        """
        Multimodal visualization with segmentation masks.

        - RGB and X views overlay masks and boxes
        - Side-by-side overlays duplicated boxes and duplicated masks
        """
        # Run parent for txt/crops but suppress image saving to avoid legacy visuals
        orig_save = getattr(self.args, 'save', False)
        try:
            self.args.save = False
            string = super().write_results(i, p, im, s)
        finally:
            self.args.save = orig_save

        if not orig_save:
            return string

        from ultralytics.utils.plotting import plot_images
        from ultralytics.models.utils.multimodal.vis import (
            visualize_x_to_3ch,
            concat_side_by_side,
            duplicate_bboxes_for_side_by_side,
            ensure_batch_idx_long,
        )
        import torch
        from pathlib import Path

        # current result
        result = self.results[i]
        base = p.stem

        # slice single sample 6-ch tensor
        if im.dim() == 4:
            im_single = im[i:i+1]
        else:
            im_single = im.unsqueeze(0) if im.dim() == 3 else im

        # separate modalities
        ch = im_single.shape[1] if im_single.dim() == 4 else im_single.shape[0]
        if ch != 6:
            # unexpected (should be 6); fallback to parent string
            return string

        # X then RGB as in training
        x_tensor = im_single[:, :3]
        rgb_tensor = im_single[:, 3:]

        # build plot args from Results
        n_boxes = 0 if result.boxes is None else len(result.boxes)
        if n_boxes:
            cls_ids = result.boxes.cls.long()
            boxes_norm = result.boxes.xywhn if hasattr(result.boxes, 'xywhn') else None
            confs = getattr(result.boxes, 'conf', None)
            if not isinstance(cls_ids, torch.Tensor):
                cls_ids = torch.as_tensor(cls_ids, dtype=torch.long)
            if boxes_norm is not None and not isinstance(boxes_norm, torch.Tensor):
                boxes_norm = torch.as_tensor(boxes_norm, dtype=torch.float32)
            if confs is not None and not isinstance(confs, torch.Tensor):
                confs = torch.as_tensor(confs, dtype=torch.float32)
            batch_idx = ensure_batch_idx_long(torch.zeros(cls_ids.shape[0]))
        else:
            cls_ids = torch.zeros((0,), dtype=torch.long)
            boxes_norm = torch.zeros((0, 4), dtype=torch.float32)
            confs = torch.zeros((0,), dtype=torch.float32)
            batch_idx = ensure_batch_idx_long(torch.zeros((0,), dtype=torch.long))

        names = getattr(self.model, 'names', {})

        # masks from results
        if getattr(result, 'masks', None) is not None and getattr(result.masks, 'data', None) is not None:
            masks = torch.as_tensor(result.masks.data, dtype=torch.uint8)
        else:
            # derive image size
            H = im_single.shape[-2]
            W = im_single.shape[-1]
            masks = torch.zeros((0, H, W), dtype=torch.uint8)

        # 1) RGB
        fname_rgb = self.save_dir / f"pred_{base}_labels_rgb.jpg"
        plot_images(rgb_tensor, batch_idx, cls_ids, boxes_norm, masks=masks, paths=[str(p)], fname=fname_rgb, names=names)

        # 2) X
        # visualize to 3ch
        x_visual = visualize_x_to_3ch(x_tensor, colorize=False, x_modality='x')
        fname_x = self.save_dir / f"pred_{base}_labels_x.jpg"
        plot_images(x_visual, batch_idx, cls_ids, boxes_norm, masks=masks,
                    paths=[str(p.with_name(f"{base}_x{p.suffix}"))], fname=fname_x, names=names)

        # 3) Side-by-side with duplicated boxes and masks
        side = concat_side_by_side(rgb_tensor, x_visual)
        batch_dup, cls_dup, boxes_dup, confs_dup = duplicate_bboxes_for_side_by_side(batch_idx, cls_ids, boxes_norm, confs)
        masks_side = torch.cat([masks, masks], dim=2) if masks.numel() else masks
        fname_mm = self.save_dir / f"pred_{base}_labels_multimodal.jpg"
        plot_images(side, batch_dup, cls_dup, boxes_dup, masks=masks_side,
                    paths=[str(p.with_name(f"{base}_multimodal{p.suffix}"))], fname=fname_mm, names=names)

        return string
