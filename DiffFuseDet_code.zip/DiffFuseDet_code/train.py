from ultralytics import YOLO

model = YOLO('/usr/MutilModel/ultralytics/cfg/models/yolov10n.yaml')
model.train(
    data='/usr/VEDAI/vedai_ir.yaml',
    epochs=1,
    batch=8,
    imgsz=1024,
    exist_ok=True,
    workers=8,
    project='/usr/yolomm/Experiment/train',
    name='VEDAI_1024_YOLO10IR',
)