"""
查看 DGA-Fusion(CAFMFusion) 模块内部结构的诊断脚本。
和之前排查 GFEM 空壳(GFEM.m length=0) 是同一套思路：
  1. 加载模型，找出所有 CAFMFusion 实例
  2. 打印每个模块的开关位(use_diff/use_gate/use_cafm) 和子模块(cafm/gate/out_conv)
  3. 注意 align_x/align_y 是惰性构建的(forward 前为 None)，
     所以先跑一次前向，再打印对齐卷积的真实通道，验证跨层级对齐没问题。
"""
import torch
from ultralytics import YOLO

# ----- 按需修改 -----
WEIGHTS = '/usr/yolomm/Experiment/train/VEDAI_kfold_1024_DGCfusion/fold_9/weights/best.pt'
RGB_IMG = '/usr/VEDAI/images/test/00000010.png'   # 改成实际存在的 RGB 图
IR_IMG  = '/usr/VEDAI/images_ir/test/00000010.png'   # 改成实际存在的 IR 图
IMG_SIZE = 1024
# --------------------

model = YOLO(WEIGHTS)
net = model.model

# 1) 找出所有 CAFMFusion 模块
cafm_list = [(name, m) for name, m in net.named_modules()
             if type(m).__name__ == 'CAFMFusion']
print(f'找到 {len(cafm_list)} 个 CAFMFusion 模块\n')

if not cafm_list:
    print('!! 一个都没找到：检查 YAML 里是否真的注册了 CAFMFusion，'
          '以及 tasks.py 的解析分支。')
    raise SystemExit

def describe(name, m, stage):
    print(f'[{stage}] {name}  (type={type(m).__name__})')
    print(f'    dim        = {getattr(m, "dim", "?")}')
    print(f'    use_diff   = {getattr(m, "use_diff", "?")}')
    print(f'    use_gate   = {getattr(m, "use_gate", "?")}')
    print(f'    use_cafm   = {getattr(m, "use_cafm", "?")}')
    cafm = getattr(m, 'cafm', None)
    print(f'    cafm       = {type(cafm).__name__ if cafm is not None else None}')
    gate = getattr(m, 'gate', None)
    if gate is not None:
        gin = gate[0].in_channels
        gout = gate[-2].out_channels  # 最后一层是 Sigmoid，取倒数第二个 Conv
        print(f'    gate       = Conv({gin}->...->{gout}) + Sigmoid')
    else:
        print(f'    gate       = None (use_gate=False)')
    oc = getattr(m, 'out_conv', None)
    if oc is not None:
        print(f'    out_conv   = Conv2d({oc.in_channels}->{oc.out_channels})')
    ax, ay = getattr(m, 'align_x', None), getattr(m, 'align_y', None)
    def fmt(a):
        if a is None:
            return 'None (未构建)'
        # align 可能是 Identity 或 Conv2d
        if hasattr(a, 'in_channels'):
            return f'Conv2d({a.in_channels}->{a.out_channels})'
        return type(a).__name__
    print(f'    align_x    = {fmt(ax)}')
    print(f'    align_y    = {fmt(ay)}')
    print()

# 2) forward 之前：align_x/align_y 应为 None
print('=' * 60)
print('前向之前（align_x/align_y 惰性构建，应为 None）')
print('=' * 60)
for name, m in cafm_list:
    describe(name, m, 'BEFORE')

# 3) 跑一次多模态前向，触发 align 卷积构建
print('=' * 60)
print('运行一次多模态前向以触发惰性构建 ...')
print('=' * 60)
try:
    model.predict(source=[RGB_IMG, IR_IMG], imgsz=IMG_SIZE, verbose=False)
    print('前向完成。\n')
except Exception as e:
    print(f'!! 前向失败：{e}')
    print('   修改脚本顶部 RGB_IMG / IR_IMG 为实际存在的图片路径后重试。\n')

# 4) forward 之后：打印真实对齐通道，验证跨层级通道对齐
print('=' * 60)
print('前向之后（应已构建 align_x/align_y，确认通道对齐）')
print('=' * 60)
for name, m in cafm_list:
    describe(name, m, 'AFTER')

print('诊断要点：')
print('  - 模块数应为 3（P3/P4/P5 三个尺度各一个）')
print('  - use_diff/use_gate/use_cafm 应与 YAML 传参一致')
print('  - 前向后 align_x/align_y 不应再是 None（否则该模块从未被调用）')
print('  - out_conv 的输出通道应等于 dim，且与下游 head 期望通道匹配')
