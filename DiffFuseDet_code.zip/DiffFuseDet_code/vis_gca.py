"""
可视化 DGA-Fusion(CAFMFusion) 模块：两路输入特征 + 融合输出。
依赖：先在 block.py 的 CAFMFusion.forward 里加好 _vis_x/_vis_y/_vis_out 缓存。
每个 CAFMFusion(P3/P4/P5) 一行，三列分别是：输入X(早融合)、输入Y(head聚合)、融合输出。
"""
import torch
import cv2
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from ultralytics import YOLO

# ----- 按需修改 -----
WEIGHTS  = '/usr/yolomm/Experiment/train/VEDAI_kfold_1024_DGCfusion/fold_9/weights/best.pt'
RGB_IMG  = '/usr/VEDAI/images/test/00001090.png'  # 改成实际图
IR_IMG   = '/usr/VEDAI/images_ir/test/00001090.png'
IMG_SIZE = 1024
SAVE     = '/usr/MutilModel/dgafusion_vis.png'
# --------------------

model = YOLO(WEIGHTS)
net = model.model

mods = [m for m in net.modules() if type(m).__name__ == 'CAFMFusion']
print(f'找到 {len(mods)} 个 CAFMFusion 模块')
if not mods:
    raise SystemExit('没找到 CAFMFusion，检查权重/YAML')

for m in mods:
    m._vis_enable = True

# 多模态前向，触发缓存
model.predict(source=[RGB_IMG, IR_IMG], imgsz=IMG_SIZE, verbose=False)


def feat_to_heatmap(feat, out_size, mode='l2'):
    """通道压成单图 + 1%-99% 百分位裁剪归一化，避免离群值压扁对比度。"""
    f = feat[0]
    if mode == 'mean':
        m = f.mean(0)
    elif mode == 'abs':
        m = f.abs().mean(0)
    else:  # l2
        m = f.pow(2).mean(0).sqrt()
    m = m.cpu().numpy()
    lo, hi = np.percentile(m, 1), np.percentile(m, 99)
    m = np.clip(m, lo, hi)
    m = (m - lo) / (hi - lo + 1e-8)
    return cv2.resize(m, out_size)


def load_img(path, out_size):
    img = cv2.imread(path)
    if img is None:
        return None
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    return cv2.resize(img, out_size)


out_size = (256, 256)

# 只取第一个 CAFMFusion(高分辨率尺度)，5 张图排成一行
m = mods[0]
if not hasattr(m, '_vis_x'):
    raise SystemExit('第一个 CAFMFusion 模块没缓存到，检查 forward 是否加了 _vis_enable')

fig, axes = plt.subplots(1, 5, figsize=(15, 3))
titles = ['(a) RGB', '(b) Infrared', '(c) Early-fusion feat.', '(d) Head-agg feat.', '(e) DGA-Fusion output']

rgb_disp = load_img(RGB_IMG, out_size)
ir_disp = load_img(IR_IMG, out_size)
hm_x = feat_to_heatmap(m._vis_x, out_size)
hm_y = feat_to_heatmap(m._vis_y, out_size)
hm_out = feat_to_heatmap(m._vis_out, out_size)

panels = [rgb_disp, ir_disp, hm_x, hm_y, hm_out]
for ax, img, t in zip(axes, panels, titles):
    if img is not None and img.ndim == 3:
        ax.imshow(img)
    else:
        ax.imshow(img, cmap='jet')
    ax.set_title(t, fontsize=10)
    ax.axis('off')

plt.tight_layout()
plt.savefig(SAVE, dpi=150, bbox_inches='tight')
print(f'已保存：{SAVE}')

# 顺带打印各路统计，便于判断是否有信号
for i, m in enumerate(mods):
    if hasattr(m, '_vis_x'):
        sname = scale_names[i] if i < len(scale_names) else f'#{i}'
        for tag, feat in [('X', m._vis_x), ('Y', m._vis_y), ('OUT', m._vis_out)]:
            f = feat[0].pow(2).mean(0).sqrt().cpu().numpy()
            print(f'{sname} {tag:3s}  std={f.std():.4f}  max={f.max():.4f}  shape={tuple(feat.shape)}')
