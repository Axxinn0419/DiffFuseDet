from ultralytics import YOLO,RTDETR

#model = YOLO('/usr/yolomm/Experiment/train/VEDAI_1024_YOLO12IR/weights/best.pt')
model = RTDETR('/usr/yolomm/Experiment/train/VEDAI_1024_RTDETRrgb/weights/best.pt')
# 运行基准测试（自动测量速度）
results = model.benchmark(
    data='/usr/VEDAI/vedai_rgb.yaml',
    imgsz=1024,
    batch=1,
    device='0',
    half=False,
)