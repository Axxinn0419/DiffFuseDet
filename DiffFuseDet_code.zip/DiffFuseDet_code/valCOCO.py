#这是专门的COCO指标计算方法，请参考我的使用方法
#我的这些参数方法是可以调整，请你根据你的项目调试
from ultralytics import YOLOMM

model = YOLOMM('/usr/yolomm/Experiment/train/VEDAI_1024/weights/best.pt')
model.cocoval(data='/usr/VEDAI/vedai.yaml',
          split='val',device='0',half=False,
imgsz=1024,batch=1,
        #   modality='x',
          project='/usr/yolomm/Experiment/val',
          name='Valcoco')