from ultralytics import YOLOMM
import cv2
import numpy as np


def ensure_3channel(img_path):
    """确保图像为3通道RGB"""
    img = cv2.imread(img_path, cv2.IMREAD_UNCHANGED)

    if img is None:
        raise ValueError(f"无法读取图像: {img_path}")

    # 检查通道数
    if len(img.shape) == 2:  # 灰度图
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
    elif img.shape[2] == 4:  # RGBA
        img = cv2.cvtColor(img, cv2.COLOR_BGRA2RGB)
    elif img.shape[2] == 3:  # BGR
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    return img


model = YOLOMM('/usr/yolomm/Experiment/train/VEDAI_GFEM_GCAFusion_kfold/fold_6/weights/best.pt')

# 预处理图像
rgb_img = ensure_3channel('/usr/yolomm/dataset/VEDAI/images/test/00000930.png')
x_img = ensure_3channel('/usr/yolomm/dataset/VEDAI/images_ir/test/00000930.png')

model.vis(
    rgb_source=rgb_img,  # 直接传入处理后的数组
    x_source=x_img,
    method='heatmap',
    layers=[41],
    overlay='rgb',
    alg='gradcam',
    save=True,
    project='/usr/yolomm/Experiment/heatmap',
    name='YOLOMM_ALL'
)