#这是提供 参考示例的 YOLOMM验证器使用方法
#按必须按照你的需求来更改而不是盲目去使用
from ultralytics import YOLOMM

model = YOLOMM('/usr/yolomm/Experiment/train/VEDAI_kfold_1024_DGCfusion/fold_9/weights/best.pt')
model.val(data='/usr/yolomm/Experiment/train/VEDAI_kfold_1024_DGCfusion/fold_9/dataset/fold_9.yaml',
          split='val',device='0',
imgsz=1024,
        #   modality='x',模态消融参数 非必要不得开启
          project='/usr/yolomm/Experiment/val',
          name='Val_VEADAI_dgca_1024')