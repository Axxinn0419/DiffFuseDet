import torch, cv2, numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from ultralytics import YOLOMM
import os

# ============ 配置参数 ============
WEIGHTS = '/usr/yolomm/Experiment/train/VEDAI_kfold_1024GFEM/fold_1/weights/best.pt'
RGB_PATH = '/usr/VEDAI/images/train/00000025.png'
IR_PATH = '/usr/VEDAI/images_ir/train/00000025.png'
OUTPUT_DIR = '/usr/MutilModel/gfem_vis_results/25'
IMG_SIZE = 1024
VIS_MODE = 'abs'  # 'mean' / 'abs' / 'l2' / 'std'
# ===================================


def feat_to_heatmap(feat, out_size, mode='abs'):
    f = feat[0]
    if mode == 'mean':
        m = f.mean(0)
    elif mode == 'abs':
        m = f.abs().mean(0)
    elif mode == 'l2':
        m = f.pow(2).mean(0).sqrt()
    elif mode == 'std':
        m = f.std(0)
    m = m.cpu().numpy()
    lo, hi = np.percentile(m, 1), np.percentile(m, 99)
    m = np.clip(m, lo, hi)
    m = (m - lo) / (hi - lo + 1e-8)
    return cv2.resize(m, out_size)


def overlay(img_bgr, hm):
    cm = cv2.applyColorMap(np.uint8(255 * hm), cv2.COLORMAP_JET)
    return cv2.addWeighted(img_bgr, 0.5, cm, 0.5, 0)


def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    print("加载模型...")
    model = YOLOMM(WEIGHTS)
    net = model.model
    net.eval()

    from ultralytics.nn.modules.block import FreqSpatial
    fs_list = [m for m in net.modules() if isinstance(m, FreqSpatial)]
    print(f'找到 {len(fs_list)} 个 FreqSpatial 模块')
    for m in fs_list:
        m._vis_enable = True

    print(f"处理: {os.path.basename(RGB_PATH)}")
    model.predict(source=[RGB_PATH, IR_PATH], imgsz=IMG_SIZE, save=False)

    original = cv2.imread(RGB_PATH)
    ir_img = cv2.imread(IR_PATH)
    H, W = original.shape[:2]

    fs = fs_list[0]

    spatial_hm = feat_to_heatmap(fs._vis_spatial, (W, H), VIS_MODE)
    freq_hm = feat_to_heatmap(fs._vis_freq, (W, H), VIS_MODE)
    final_hm = feat_to_heatmap(fs._vis_final, (W, H), VIS_MODE)

    ov_spatial = overlay(original, spatial_hm)
    ov_freq = overlay(original, freq_hm)
    ov_final = overlay(original, final_hm)

    # 单行4列对比图: 原图 | Spatial | Frequency | GFEM Output
    fig, axes = plt.subplots(1, 4, figsize=(20, 5))
    titles = ['Input(RGB)', 'Spatial Branch', 'Frequency Branch', 'GFEM']
    imgs = [original, ov_spatial, ov_freq, ov_final]

    for ax, t, im in zip(axes, titles, imgs):
        ax.imshow(im[..., ::-1])
        ax.set_title(t, fontsize=14)
        ax.axis('off')

    plt.tight_layout()
    out_path = os.path.join(OUTPUT_DIR, 'gfem_comparison.png')
    plt.savefig(out_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"对比图已保存: {out_path}")

    # 单独保存每张
    cv2.imwrite(os.path.join(OUTPUT_DIR, 'spatial.png'), ov_spatial)
    cv2.imwrite(os.path.join(OUTPUT_DIR, 'frequency.png'), ov_freq)
    cv2.imwrite(os.path.join(OUTPUT_DIR, 'gfem_output.png'), ov_final)
    print(f"单独图片已保存到: {OUTPUT_DIR}")


if __name__ == "__main__":
    main()