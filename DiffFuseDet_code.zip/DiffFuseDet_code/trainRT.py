from ultralytics import RTDETR

# 1. 加载模型
# 使用您提供的YAML文件初始化模型架构（权重将随机初始化）
model = RTDETR('/usr/MutilModel/ultralytics/cfg/models/rtdetr-l.yaml')  # 请确保路径正确

model.train(
    data='/usr/VEDAI/vedai_rgb.yaml',
    epochs=1,
    batch=8,
    imgsz=1024,
    exist_ok=True,
    workers=8,
    project='/usr/yolomm/Experiment/train',
    name='VEDAI_1024_RTDETRrgb',)