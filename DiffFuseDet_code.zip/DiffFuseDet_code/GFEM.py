from ultralytics import YOLOMM
import torch

# 加载模型
m = YOLOMM('/usr/MutilModel/ultralytics/cfg/models/yolo11n_DGCAFusion_GFEM.yaml')

# 检查GFEM模块
for mod in m.model.modules():
    if type(mod).__name__ == 'GFEM':
        print('GFEM.m length =', len(mod.m))

# 核心统计
print("\n模型统计：")
print(f"总参数量: {sum(p.numel() for p in m.model.parameters()) / 1e6:.3f} M")

# 计算 FLOPs (1024x1024)
try:
    from thop import profile, clever_format
    m.model.eval()
    # 这里改成 1024x1024
    flops, params = profile(m.model, inputs=(torch.randn(1, 3, 1024, 1024),), verbose=False)
    flops, params = clever_format([flops, params], "%.3f")
    print(f"FLOPs (1024x1024): {flops}")
    print(f"Params: {params}")
except Exception as e:
    print(f"提示：计算 FLOPs 失败 - {e}")
    print("可能原因：未安装 thop 库，或模型包含不支持 profile 的自定义操作")

# 核心统计
print("\n模型统计：")
print(f"总参数量: {sum(p.numel() for p in m.model.parameters()) / 1e6:.3f} M")

# 如果需要FLOPs
try:
    from thop import profile, clever_format
    m.model.eval()
    flops, params = profile(m.model, inputs=(torch.randn(1, 3, 640, 640),), verbose=False)
    flops, params = clever_format([flops, params], "%.3f")
    print(f"FLOPs (640x640): {flops}")
    print(f"Params: {params}")
except:
    print("提示：安装 thop 库可计算 FLOPs")
