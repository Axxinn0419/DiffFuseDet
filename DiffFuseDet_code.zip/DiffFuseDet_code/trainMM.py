import os
import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange

# ============ 系统设置 ============
torch.set_default_dtype(torch.float32)
os.environ['CUBLAS_WORKSPACE_CONFIG'] = ':4096:8'
os.environ['PYTORCH_CUDA_ALLOC_CONF'] = 'max_split_size_mb:512'
os.environ['CUDA_LAUNCH_BLOCKING'] = '1'

torch.backends.cudnn.deterministic = False
torch.backends.cudnn.benchmark = True

from ultralytics import YOLOMM


# ============ 定义修复后的 FreqSpatial ============
class FixedFreqSpatial(nn.Module):
    def __init__(self, in_channels, use_spatial=True, use_freq=True):
        super(FixedFreqSpatial, self).__init__()
        self.use_spatial = use_spatial
        self.use_freq = use_freq

        from ultralytics.nn.modules import Conv

        if self.use_spatial:
            # 直接用 ScharrConv 的简化版（避免依赖）
            self.spatial_conv1 = Conv(in_channels, in_channels)
            self.spatial_conv2 = Conv(in_channels, in_channels)

        if self.use_freq:
            self.fft_conv = Conv(in_channels * 2, in_channels * 2, 3)
            self.fft_conv2 = Conv(in_channels, in_channels, 3)

        self.final_conv = Conv(in_channels, in_channels, 1)

    def forward(self, x):
        # ===== 核心修复：强制 float32 =====
        x = x.float()  # ← 这是关键！

        batch, c, h, w = x.size()

        if self.use_spatial:
            # 简化的 Scharr 边缘检测（直接计算）
            scharr_x = torch.tensor([[-3, 0, 3], [-10, 0, 10], [-3, 0, 3]], dtype=torch.float32, device=x.device)
            scharr_y = torch.tensor([[-3, -10, -3], [0, 0, 0], [3, 10, 3]], dtype=torch.float32, device=x.device)
            scharr_x = scharr_x.view(1, 1, 3, 3).expand(c, 1, 3, 3)
            scharr_y = scharr_y.view(1, 1, 3, 3).expand(c, 1, 3, 3)

            grad_x = F.conv2d(x, scharr_x, padding=1, groups=c)
            grad_y = F.conv2d(x, scharr_y, padding=1, groups=c)
            spatial_feat = grad_x * 0.5 + grad_y * 0.5

            spatial_feat = self.spatial_conv1(spatial_feat)
            spatial_feat = self.spatial_conv2(spatial_feat + x)
        else:
            spatial_feat = x

        if self.use_freq:
            # FFT 全部用 float32
            fft_feat = torch.fft.rfft2(x, norm='ortho')
            # 确保是 complex64
            if fft_feat.dtype == torch.complex32:
                fft_feat = fft_feat.to(torch.complex64)

            x_fft_real = torch.unsqueeze(torch.real(fft_feat), dim=-1)
            x_fft_imag = torch.unsqueeze(torch.imag(fft_feat), dim=-1)
            fft_feat_cat = torch.cat((x_fft_real, x_fft_imag), dim=-1)
            fft_feat_cat = rearrange(fft_feat_cat, 'b c h w d -> b (c d) h w').contiguous()

            fft_feat_cat = self.fft_conv(fft_feat_cat)

            fft_feat_cat = rearrange(fft_feat_cat, 'b (c d) h w -> b c h w d', d=2).contiguous()
            fft_feat_complex = torch.view_as_complex(fft_feat_cat)
            if fft_feat_complex.dtype == torch.complex32:
                fft_feat_complex = fft_feat_complex.to(torch.complex64)

            fft_feat = torch.fft.irfft2(fft_feat_complex, s=(h, w), norm='ortho')
            fft_feat = self.fft_conv2(fft_feat)
        else:
            fft_feat = torch.zeros_like(x)

        out = spatial_feat + fft_feat
        final = self.final_conv(out)

        return final


# ============ Monkey Patch ============
import ultralytics.nn.modules

ultralytics.nn.modules.FreqSpatial = FixedFreqSpatial
# 同时替换 GFEM 中使用的 FreqSpatial
ultralytics.nn.modules.GFEM = type('FixedGFEM', (ultralytics.nn.modules.C2f,), {
    '__init__': lambda self, c1, c2, n=1, shortcut=False, g=1, e=0.5, use_spatial=True, use_freq=True:
    ultralytics.nn.modules.C2f.__init__(self, c1, c2, n, shortcut, g, e) or
    setattr(self, 'm',
            nn.ModuleList(FixedFreqSpatial(self.c, use_spatial=use_spatial, use_freq=use_freq) for _ in range(n)))
})

print("✅ 已应用 FreqSpatial 修复！")

# ============ 训练 ============
if __name__ == '__main__':
    model = YOLOMM('/usr/MutilModel/ultralytics/cfg/models/yolo11n_DGCAFusion_GFEM.yaml')
    model.model = model.model.float()

    model.train(
        data='/usr/M3FD_split/data.yaml',
        epochs=300,
        batch=8,
        imgsz=1024,
        exist_ok=True,
        workers=8,
        resume=False,
        amp=False,  # 关键
        project='/usr/yolomm/Experiment/train',
        name='M3FD'
    )